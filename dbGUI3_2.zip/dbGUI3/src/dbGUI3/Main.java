package dbGUI3;

import java.io.File;
import java.util.Locale;

import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxRequestConfig;

public class Main {
	
    private final static String APP_KEY = "8i7ojq3l3a17n3t";
    private final static String APP_SECRET = "qyyul19ennb91be";	

    private static DbxAppInfo appInfo = new DbxAppInfo(APP_KEY, APP_SECRET);
    private static DbxRequestConfig config = new DbxRequestConfig("Chicken",
        Locale.getDefault().toString());

    private static File accessTokensFile = new File("savedAuthToken.txt");	// file path of stored authorization token    
    
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			// creating application window
			MainWindow applicationWindow = new MainWindow();
			
			applicationWindow.setVisible(true);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static DbxAppInfo getAppInfo(){
		return appInfo;
	}
	
	public static DbxRequestConfig getConfig(){
		return config;
	}

	public static File getAccessTokensFile() {
		return accessTokensFile;
	}

	public static void setAccessTokensFile(File accessTokensFile) {
		Main.accessTokensFile = accessTokensFile;
	}

}
