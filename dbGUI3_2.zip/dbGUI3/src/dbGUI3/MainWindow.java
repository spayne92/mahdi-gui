package dbGUI3;

import javax.swing.JFrame;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import com.dropbox.core.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;
import net.miginfocom.swing.MigLayout;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;
import java.io.*;

public class MainWindow extends JFrame{

	private static final long serialVersionUID = 1L;

	private Vector <User> usersList = new Vector <User>(2);
	
	private static DbxClient activeUser;
	private DbxRequestConfig copyConfig = Main.getConfig();
	private JTextField directoryPathField;
	private static String directoryPath;
	private static String appDirectory = "/SecureBox/";

	/**
	 * Create the application.
	 */
	public MainWindow() {
		addWindowListener(new WindowAdapter() {
			
			// stores data about users upon window closing
			@Override
			public void windowClosing(WindowEvent e) {
				try {
					
					// variable for writing to accessTokensFile
					PrintWriter pw = new PrintWriter(new FileWriter(Main.getAccessTokensFile()));
					
					for(int i = 0; i < usersList.size(); i++){
						//System.out.println(usersList.get(i).getClient().getAccessToken());
						
						// stores all users access tokens in output file
						pw.println(usersList.get(i).getClient().getAccessToken());
					}
					
					pw.close();	
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
			
			// updates data from file upon window opening
			@Override
			public void windowOpened(WindowEvent e) {
				try {
					
					// variables needed for reading from accessTokensFile
					BufferedReader br = new BufferedReader(new FileReader(Main.getAccessTokensFile()));
					String line = null;
					
					// while file is not empty, creates new users with access
					//	tokens contained on each line
					while((line = br.readLine()) != null){
						createUser(line);
					}
					
					br.close();
					
					if(usersList.size() > 0){
						updateActiveUser(usersList.get(0).getClient());
					}
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnUser = new JMenu("User");
		menuBar.add(mnUser);
		
		JMenu mnSelect = new JMenu("Select");
		
		// upon mouse hover, checks if select menu is empty and usersList is 
		//	not, in which case it populates the select menu with all users 
		mnSelect.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				if(mnSelect.getItemCount() == 0 && usersList.size() > 0){
					updateUserSelections(mnSelect);
				}
			}
		});
		mnUser.add(mnSelect);
		
		JMenuItem mntmAdd = new JMenuItem("Add");
		mntmAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				AuthenticationWindow popUpAuth = new AuthenticationWindow();
				
				// causes dialog window to become visible and returns 
				//		accessToken upon close
				String accessToken = popUpAuth.showDialog();
				
				// testing success of authentication process
				if(accessToken != null){
					System.out.println("User Created");
				}else
					System.out.println("Null");
				
				// creates new user profile using retrieved access token
				createUser(accessToken);
				updateUserSelections(mnSelect);
			}
		});
		mnUser.add(mntmAdd);
		getContentPane().setLayout(new MigLayout("", "[grow]", 
										 "[][grow]"));
		
		JButton btnUpdateDirectory = new JButton("Update Directory");
		btnUpdateDirectory.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				File testPath = new File(directoryPathField.getText());
				if(testPath.isFile()) {
					directoryPath = directoryPathField.getText();	
					try {
						FileInputStream inputStream = new FileInputStream(testPath);
						DbxEntry.File upload = activeUser.uploadFile(appDirectory + directoryPath, 
								DbxWriteMode.add(), testPath.length(), inputStream);
						System.out.println("Uploaded: " + upload.toString());
						inputStream.close();
					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
						System.out.println("FNF");
					} catch(IOException ex) {
						ex.printStackTrace();
						System.out.println("IO");
					} catch(DbxException ex) {
						ex.printStackTrace();
					}
				} else {
					directoryPathField.setText("Please input valid directory or file name.");
				}
			}
		});
		getContentPane().add(btnUpdateDirectory, "flowx,cell 0 0");
		
		directoryPathField = new JTextField();
		getContentPane().add(directoryPathField, "cell 0 0,growx");
		directoryPathField.setColumns(10);
		
		JList fileList = new JList();
		getContentPane().add(fileList, "cell 0 1,grow");
	}
	
	public void createUser(String accessToken){
		
		// creates a new user and adds it to the usersList
		usersList.add(new User(copyConfig, accessToken));
		// prints list of users each time a new one is added, for testing
		for(int i = 0; i < usersList.size(); i++){
			//System.out.println(usersList.get(i).userName);
		}
	}
	
	public void updateUserSelections(JMenu select){
		
		// temporary variables for dynamically generating select menu
		Vector<JRadioButton> tempUserButtons = new Vector<JRadioButton>();
		ButtonGroup tempButtonGroup = new ButtonGroup();

		// iterates through each existing user
		for(int i = 0; i < usersList.size(); i++){
			
			// defines a client based on the current user in the usersList
			DbxClient tempClient = usersList.get(i).getClient();
			
			// creates a new JRadioButton with the name of the current user
			tempUserButtons.add(new JRadioButton(usersList.get(i).userName));
			
			// adds mousePressed action to update active user to current user 
			//		when its button is pressed 
			tempUserButtons.get(i).addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					updateActiveUser(tempClient);
					//System.out.println("User successfully chosen as active.");
				}
			});
	
			// adds current user to ButtonGroup of users, allowing only one to
			//		be selected at a time
			tempButtonGroup.add(tempUserButtons.get(i));
			// adds current user to select menu, so that it becomes visible
			select.add(tempUserButtons.get(i));
		}
		
		// if no other user button has been selected, makes the first user in 
		//		usersList the active user and activates the button that 
		//		represents it, to designate its active status
		if(tempButtonGroup.getSelection() == null || usersList.size() <= 1){
			updateActiveUser(usersList.get(0).getClient());
			tempUserButtons.get(0).setSelected(true);
		}
	}
	
	public void updateActiveUser(DbxClient userClient){
		activeUser = userClient; 
	}
}
