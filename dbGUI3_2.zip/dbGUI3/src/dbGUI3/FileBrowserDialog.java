package dbGUI3;

import javax.swing.JDialog;

public class FileBrowserDialog extends JDialog {
	
	static String path;
	
	public FileBrowserDialog() {
		
	}
	
	public String showFileBrowser() {
		setVisible(true);
		return path;
	}

}
