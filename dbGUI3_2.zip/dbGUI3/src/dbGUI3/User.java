package dbGUI3;

import com.dropbox.core.DbxClient;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;

public class User {
	
	private DbxClient client;
	public String userName;
	
	public User(DbxRequestConfig config, String passedAccessToken){
		setClient(new DbxClient(config, passedAccessToken));
		try {
			userName = getClient().getAccountInfo().displayName;
		} catch (DbxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return the client
	 */
	public DbxClient getClient() {
		return client;
	}

	/**
	 * @param client the client to set
	 */
	public void setClient(DbxClient client) {
		this.client = client;
	}
}
