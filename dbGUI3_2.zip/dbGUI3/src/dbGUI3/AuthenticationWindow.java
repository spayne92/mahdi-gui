package dbGUI3;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.dropbox.core.DbxAppInfo;
import com.dropbox.core.DbxAuthFinish;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxWebAuthNoRedirect;

import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AuthenticationWindow extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9044863073602501115L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtPasteCodeHere;
	
	private DbxAppInfo copyAppInfo = Main.getAppInfo();
	private DbxRequestConfig copyConfig = Main.getConfig();
	
    private DbxWebAuthNoRedirect webAuth = new DbxWebAuthNoRedirect(copyConfig, copyAppInfo);	
    private String authorizeUrl = webAuth.start();    
    private DbxAuthFinish authFinish;
    
    private String accessToken = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			AuthenticationWindow dialog = new AuthenticationWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public AuthenticationWindow() {
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Generate Code");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					java.awt.Desktop.getDesktop().browse(java.net.URI.create(authorizeUrl));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(120, 50, 180, 25);
		contentPanel.add(btnNewButton);
		
		txtPasteCodeHere = new JTextField();
		txtPasteCodeHere.setToolTipText("Paste authentication code here.");
		txtPasteCodeHere.setText("Paste authentication code here.");
		txtPasteCodeHere.setBounds(96, 141, 240, 31);
		contentPanel.add(txtPasteCodeHere);
		txtPasteCodeHere.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Authenticate");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent e) {
						String code = txtPasteCodeHere.getText();
						try {
							authFinish = webAuth.finish(code);
							accessToken = authFinish.accessToken;
							dispose();
						} catch (DbxException.BadRequest el){
							txtPasteCodeHere.setText("Code doesn't exist or has expired.");
						} catch (DbxException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
							txtPasteCodeHere.setText("Code doesn't exist or has expired.");
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						accessToken = null;
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	public String showDialog() {
		// TODO Auto-generated method stub
		setVisible(true);
		return accessToken;
	}
}
